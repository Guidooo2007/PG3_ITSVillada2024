def main():
    try:
        num1 = float(input("Ingrese el primer numero: "))
        num2 = float(input("Ingrese el segundo numero: "))
        
        division = num1 / num2
        print(f"La division de {num1} respecto a {num2} es: {division}")
    except ZeroDivisionError:
        print("Error: No se puede dividir por cero")

if __name__ == "__main__":
    main()
    