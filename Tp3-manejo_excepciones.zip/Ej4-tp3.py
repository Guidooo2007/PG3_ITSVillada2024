def realizar_division():
    try:
        numero1 = float(input("Ingrese el primer numero: "))
        numero2 = float(input("Ingrese el segundo numero: "))
        
        resultado = numero1 / numero2
        print("El resultado de la division es:", resultado)
        
    except ValueError:
        print("Error: Por favor ingrese solo numeros validos.")
    except ZeroDivisionError:
        print("Error: No se puede dividir por cero")

if __name__ == "__main__":
    realizar_division()
