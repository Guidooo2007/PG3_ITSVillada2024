try:
    with open("archivo.txt", "w") as archivo:
        archivo.write("Hola\n")
        archivo.write("Este es un ejemplo\n")
        archivo.write("de almacenamiento\n")
        archivo.write("de strings en un archivo de texto.\n")
        
        archivo.write(42)  
except TypeError as e:
    print("Error: Se ha producido un error de tipo:", e)
    
